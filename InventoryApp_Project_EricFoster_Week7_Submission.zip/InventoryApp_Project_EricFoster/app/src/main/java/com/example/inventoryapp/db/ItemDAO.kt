package com.example.inventoryapp.db

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import com.example.inventoryapp.models.InventoryItem

class ItemDAO(context: Context) {
    private val dbHelper = DBHelper(context)

    fun addItem(userId: Int, name: String, qty: Int): Boolean {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(DBHelper.COL_ITEM_NAME, name)
            put(DBHelper.COL_ITEM_QTY, qty)
            put(DBHelper.COL_ITEM_USER_ID, userId)
        }
        return db.insert(DBHelper.TABLE_ITEMS, null, values) != -1L
    }

    fun getAllItems(userId: Int): List<InventoryItem> {
        val db = dbHelper.readableDatabase
        val list = mutableListOf<InventoryItem>()
        val cursor: Cursor = db.query(
            DBHelper.TABLE_ITEMS,
            null,
            "${DBHelper.COL_ITEM_USER_ID}=?",
            arrayOf(userId.toString()),
            null, null, null
        )
        while (cursor.moveToNext()) {
            val id = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.COL_ITEM_ID))
            val name = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_ITEM_NAME))
            val qty = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.COL_ITEM_QTY))
            list.add(InventoryItem(id, name, qty))
        }
        cursor.close()
        return list
    }


    fun updateItemQty(id: Int, qty: Int): Boolean {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(DBHelper.COL_ITEM_QTY, qty)
        }
        return db.update(DBHelper.TABLE_ITEMS, values, "${DBHelper.COL_ITEM_ID}=?", arrayOf(id.toString())) > 0
    }

    fun deleteItem(id: Int): Boolean {
        val db = dbHelper.writableDatabase
        return db.delete(DBHelper.TABLE_ITEMS, "${DBHelper.COL_ITEM_ID}=?", arrayOf(id.toString())) > 0
    }
}
