package com.example.inventoryapp

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.inventoryapp.db.ItemDAO
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton

class ItemDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_detail)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val name = intent.getStringExtra("item_name") ?: "Item"
        val qty = intent.getIntExtra("item_qty", 0)
        val itemId = intent.getIntExtra("item_id", -1)  // NEW: get item ID
        val itemDAO = ItemDAO(this)                     // NEW: DAO for DB ops

        val tvName = findViewById<TextView>(R.id.tv_item_name)
        val tvQty = findViewById<TextView>(R.id.tv_item_qty)
        tvName.text = name
        tvQty.text = qty.toString()

        // Remove item from DB
        findViewById<MaterialButton>(R.id.btn_remove).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Remove Item")
                .setMessage("This will remove the item from inventory. Continue?")
                .setPositiveButton("Yes") { _, _ ->
                    if (itemId != -1) {
                        itemDAO.deleteItem(itemId)
                        Toast.makeText(this, "Item removed", Toast.LENGTH_SHORT).show()
                    }
                    finish()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Increment item quantity in DB
        findViewById<MaterialButton>(R.id.btn_plus).setOnClickListener {
            val current = tvQty.text.toString().toInt()
            val newVal = current + 1
            tvQty.text = newVal.toString()
            if (itemId != -1) itemDAO.updateItemQty(itemId, newVal)
        }

        // Decrement item quantity in DB
        findViewById<MaterialButton>(R.id.btn_minus).setOnClickListener {
            val current = tvQty.text.toString().toInt()
            val newVal = (current - 1).coerceAtLeast(0)
            tvQty.text = newVal.toString()
            if (itemId != -1) itemDAO.updateItemQty(itemId, newVal)
        }

        // Handles update button interaction
        findViewById<MaterialButton>(R.id.btn_update).setOnClickListener {
            val newVal = tvQty.text.toString().toIntOrNull() ?: 0
            if (itemId != -1) {
                itemDAO.updateItemQty(itemId, newVal)
                Toast.makeText(this, "Quantity updated", Toast.LENGTH_SHORT).show()
                finish()
            }
        }

    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
