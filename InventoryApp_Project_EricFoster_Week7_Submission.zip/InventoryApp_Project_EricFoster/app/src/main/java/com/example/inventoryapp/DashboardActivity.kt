package com.example.inventoryapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.inventoryapp.db.ItemDAO
import com.google.android.material.floatingactionbutton.FloatingActionButton

class DashboardActivity : AppCompatActivity() {
    private lateinit var recycler: RecyclerView
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        recycler = findViewById(R.id.recycler_inventory)
        recycler.layoutManager = GridLayoutManager(this, 2)

        loadItems()

        findViewById<FloatingActionButton>(R.id.fab_add).setOnClickListener {
            userId = intent.getIntExtra("user_id", -1)
            if (userId != -1) {
                val intent = Intent(this, AddItemActivity::class.java)
                intent.putExtra("user_id", userId)
                startActivity(intent)
            } else {
                Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
            }
        }

    }

    override fun onResume() {
        super.onResume()
        loadItems()
    }

    private fun loadItems() {
        // Get userId from the intent (passed from login)
        val userId = intent.getIntExtra("user_id", -1)

        // Initialize your DAO
        val itemDAO = ItemDAO(this)

        // Fetch items for this specific user
        val items = itemDAO.getAllItems(userId)

        // Set the RecyclerView adapter
        recycler.adapter = InventoryAdapter(items) { item ->
            val intent = Intent(this, ItemDetailActivity::class.java).apply {
                putExtra("item_id", item.id)
                putExtra("item_name", item.name)
                putExtra("item_qty", item.quantity)
                putExtra("user_id", userId)
            }
            startActivity(intent)
        }
    }

}
