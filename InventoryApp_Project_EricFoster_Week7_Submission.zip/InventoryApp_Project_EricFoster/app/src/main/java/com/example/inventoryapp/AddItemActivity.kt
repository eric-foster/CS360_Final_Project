package com.example.inventoryapp

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.inventoryapp.db.ItemDAO
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class AddItemActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_item)

        val etName = findViewById<TextInputEditText>(R.id.et_name)
        val etQty = findViewById<TextInputEditText>(R.id.et_qty)
        val submit = findViewById<MaterialButton>(R.id.btn_submit)

        submit.setOnClickListener {
            val name = etName.text.toString()
            val qty = etQty.text.toString().toIntOrNull() ?: 0
            val userId = intent.getIntExtra("user_id", -1)
            val itemDAO = ItemDAO(this)

            if (itemDAO.addItem(userId, name, qty)) {
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show()
                finish() // return to dashboard
            } else {
                Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show()
            }
        }
    }
}