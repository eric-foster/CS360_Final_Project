package com.example.inventoryapp.db

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import com.example.inventoryapp.models.User

class UserDAO(context: Context) {
    private val dbHelper = DBHelper(context)

    fun registerUser(username: String, password: String): Boolean {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(DBHelper.COL_USERNAME, username)
            put(DBHelper.COL_PASSWORD, password)
        }
        return db.insert(DBHelper.TABLE_USERS, null, values) != -1L
    }

    fun loginUser(username: String, password: String): Int {
        val db = dbHelper.readableDatabase
        val cursor: Cursor = db.query(
            DBHelper.TABLE_USERS,
            arrayOf(DBHelper.COL_USER_ID),
            "${DBHelper.COL_USERNAME}=? AND ${DBHelper.COL_PASSWORD}=?",
            arrayOf(username, password),
            null, null, null
        )
        var userId = -1
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.COL_USER_ID))
        }
        cursor.close()
        return userId
    }
}
