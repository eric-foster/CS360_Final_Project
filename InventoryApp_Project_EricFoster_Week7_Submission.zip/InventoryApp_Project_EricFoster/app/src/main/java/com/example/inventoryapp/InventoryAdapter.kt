package com.example.inventoryapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.inventoryapp.models.InventoryItem


class InventoryAdapter(
    private val items: List<InventoryItem>,
    private val onItemClick: (InventoryItem) -> Unit
) : RecyclerView.Adapter<InventoryAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val card = view.findViewById<CardView>(R.id.card_item)
        val name = view.findViewById<TextView>(R.id.tv_name)
        val qty = view.findViewById<TextView>(R.id.tv_qty)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_inventory, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.name.text = item.name
        holder.qty.text = item.quantity.toString()
        // color-code low stock
        val colorRes = if (item.quantity == 0) R.color.low_stock else R.color.in_stock
        holder.card.setCardBackgroundColor(holder.itemView.context.getColor(colorRes))
        holder.card.setOnClickListener { onItemClick(item) }
    }

    override fun getItemCount(): Int = items.size
}