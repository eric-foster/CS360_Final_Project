package com.example.inventoryapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.inventoryapp.db.UserDAO
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class LoginActivity : AppCompatActivity() {
    private lateinit var userDAO: UserDAO

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        userDAO = UserDAO(this)

        val etEmail = findViewById<TextInputEditText>(R.id.et_email)
        val etPassword = findViewById<TextInputEditText>(R.id.et_password)
        val loginButton = findViewById<MaterialButton>(R.id.btn_login)
        val registerButton = findViewById<MaterialButton>(R.id.btn_register)

        // LOGIN BUTTON
        loginButton.setOnClickListener {
            val username = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Must type a username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val userId = userDAO.loginUser(username, password)
            if (userId != -1) {
                val intent = Intent(this, DashboardActivity::class.java)
                intent.putExtra("user_id", userId) // pass logged in user’s ID
                startActivity(intent)
                finish() // prevent going back to login
            } else {
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show()
            }
        }

        // REGISTER BUTTON
        registerButton.setOnClickListener {
            val username = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Must type a username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (userDAO.registerUser(username, password)) {
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "User already exists", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

