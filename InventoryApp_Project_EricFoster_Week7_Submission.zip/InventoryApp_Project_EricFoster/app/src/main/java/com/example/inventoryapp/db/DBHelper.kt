package com.example.inventoryapp.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        // Create users table
        db.execSQL(
            "CREATE TABLE $TABLE_USERS (" +
                    "$COL_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "$COL_USERNAME TEXT UNIQUE, " +
                    "$COL_PASSWORD TEXT)"
        )

        // Create inventory table
        db.execSQL(
            "CREATE TABLE $TABLE_ITEMS (" +
                    "$COL_ITEM_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "$COL_ITEM_NAME TEXT NOT NULL, " +
                    "$COL_ITEM_QTY INTEGER NOT NULL, " +
                    "user_id INTEGER NOT NULL, " +
                    "FOREIGN KEY(user_id) REFERENCES $TABLE_USERS($COL_USER_ID))"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ITEMS")
        onCreate(db)
    }

    companion object {
        private const val DATABASE_NAME = "inventory_app.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_USERS = "users"
        const val COL_USER_ID = "id"
        const val COL_USERNAME = "username"
        const val COL_PASSWORD = "password"

        const val TABLE_ITEMS = "items"
        const val COL_ITEM_ID = "id"
        const val COL_ITEM_NAME = "name"
        const val COL_ITEM_QTY = "quantity"
        const val COL_ITEM_USER_ID = "user_id"
    }
}
