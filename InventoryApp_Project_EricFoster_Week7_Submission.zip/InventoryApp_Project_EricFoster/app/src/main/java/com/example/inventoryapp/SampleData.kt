//package com.example.inventoryapp
//
//data class InventoryItem(val id: Int, val name: String, val quantity: Int)
//
//object SampleData {
//    fun generate(): List<InventoryItem> {
//        return listOf(
//            InventoryItem(1, "Widget A", 12),
//            InventoryItem(2, "Widget B", 0),
//            InventoryItem(3, "Gadget 1", 5),
//            InventoryItem(4, "Gadget 2", 2),
//            InventoryItem(5, "Small Part", 0),
//            InventoryItem(6, "Large Part", 20)
//        )
//    }
//}